export const page_size = 100;
export const start_year = 2014;
export const end_year = 2020;
export const baseURL = "https://www.balldontlie.io/api/v1/";
