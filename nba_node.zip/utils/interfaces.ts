export interface IStat {
    Above50: number
    Below50: number
}